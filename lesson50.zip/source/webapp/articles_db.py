class ArticlesDB:
    articles = []
    cat_avatar = "images/smile.png"


    @staticmethod
    def set_new_avatar():
        ArticlesDB.cat_avatar = "images/cat.jpg"

